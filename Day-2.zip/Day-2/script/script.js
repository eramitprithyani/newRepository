$(document).ready(function(){
    $(".fa").click(function(){
       $("#dial").hide();
    });
});

$(document).ready(function(){
    $("#testing").mouseover(function() {
        $(".over").css("display","block");
        $("this button").css("border","2px solid white");
    });

    $("#testing").mouseout(function() {
        $(".over").css("display","none");
        
    });

    $("#testing1").mouseover(function() {
        $(".over1").css("display","block");
        $("this button").css("border","2px solid white");
    });

    $("#testing1").mouseout(function() {
        $(".over1").css("display","none");
        
    });

    $("#testing2").mouseover(function() {
        $(".over2").css("display","block");
        $("this button").css("border","2px solid white");
    });

    $("#testing2").mouseout(function() {
        $(".over2").css("display","none");
        
    });

    $("#testing3").mouseover(function() {
        $(".over3").css("display","block");
        $("this button").css("border","2px solid white");
    });

    $("#testing3").mouseout(function() {
        $(".over3").css("display","none");
        
    });

    $(".over a").click(function(){
        $(".over a").css("border","2px solid white");
        $(".over a").css("backgroundColor","transparent");
    });
});
/*
$(document).ready(function(){
        
    $("#testing").mouseover(function(){
       $("#s1 i").detach();
       $("#s1 p").detach();
       $("#s1").css("backgroundColor","#04acdd");
        $("#s1").append( "<h3><b>STRATEGIC</b></h3>" );
        $("#s1").append( "<b>PARTNER</b>" );
        $("#s1").append("<p>A Strategic Partner (SP) is a representative of AZON Global Trade, their role as strategic partner enjoys the art of negotiating business transactions between parties.</p>")
    });
     

});
                  
    $(document).ready(function(){
$("#s1").mouseout(function(){
     $("#s1").css("backgroundColor","");
     $("i").show();
     $(this).css("color","");  
     $( "h3" ).detach( );
     $( "b" ).detach( );
     $( "#s1 p" ).detach( );
    $("#s1").append("<i></i>").addClass("fa fa-user");
    $("#s1").append("<p>STRATEGIC PARTNER</p>");
     
  
  
  
});
    });
                  
                  
$("#s1").mouseover(function(){
    $("#s1").css("backgroundColor","#04acdd");
    $(".test").hide();
    $( "#s1" ).append( "<h3><b>STRATEGIC</b></h3>" );
    $(this).append( "<p><b>PARTNER</b></p>" );
    $(this).append("<p>A Strategic Partner (SP) is a representative of AZON Global Trade, their role as strategic partner enjoys the art of negotiating business transactions between parties.</p>");
   
   
    $(this).css("color","white");
    
});
    $("#s2").mouseover(function(){
    $("#s2").css("backgroundColor","#04acdd");
    $(".test").hide();
    $( "#s2" ).append( "<h3><b>WHAT</b></h3>" );
    
   
    $(this).css("color","white");
    
});
    
    $("#s3").mouseover(function(){
    $("#s3").css("backgroundColor","#04acdd");
    $(".test").hide();
    $( "#s3" ).append( "<h3><b>HOW</b></h3>" );
   
   
    $(this).css("color","white");
    
});
    $("#s4").mouseover(function(){
    $("#s4").css("backgroundColor","#04acdd");
    $(".test").hide();
    $( "#s4" ).append( "<h3><b>WHY</b></h3>" );
    
   
    $(this).css("color","white");
    
});
});

$(document).ready(function(){
$("#s1").mouseout(function(){
     $("#s1").css("backgroundColor","");
     $(".test").show();
      $(this).css("color","");  
    $( "h3" ).detach( );
  
  
  
});
    
    $("#s2").mouseout(function(){
     $("#s2").css("backgroundColor","");
     $(".test").show();
      $(this).css("color","");  
    $( "h3" ).detach( );
    
  
  
});
    $("#s3").mouseout(function(){
     $("#s3").css("backgroundColor","");
     $(".test").show();
      $(this).css("color","");  
    $( "h3" ).detach( );
  
  
  
});
    
    $("#s4").mouseout(function(){
     $("#s4").css("backgroundColor","");
     $(".test").show();
      $(this).css("color","");  
    $( "h3" ).detach( );
    
  
  
});
});

*/