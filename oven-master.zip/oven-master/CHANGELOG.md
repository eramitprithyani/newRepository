Changelog
=========

Releases
--------
* 1.1.0
  * Ability to install to a custom sub dir
  * Ability to use system wide composer
  * Database configuration
  * CakePHP stable/beta minimum stability selector

* 1.0.0
  * Initial working version
